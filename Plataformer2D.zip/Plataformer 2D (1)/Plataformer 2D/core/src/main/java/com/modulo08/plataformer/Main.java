package com.modulo08.plataformer;

import com.badlogic.gdx.Game;
import com.modulo08.plataformer.screens.GameScreen;

public class Main extends Game {
    @Override
    public void create() {
        setScreen(new GameScreen(this));
    }
}
