package com.modulo08.plataformer.entities;

import com.badlogic.gdx.physics.box2d.*;
import com.modulo08.plataformer.systems.TileMapLoader;
import com.modulo08.plataformer.systems.TipoColisor;

public class Enemy {

    public static final float LARGURA = 0.6f;
    public static final float ALTURA = 0.6f;
    private static final float VELOCIDADE = 2f;
    private static final float DISTANCIA_DE_DETECCAO = LARGURA / 2f + 0.15f;

    private final Body body;
    private final int[][] nivel;
    private final float waypointEsquerda;
    private final float waypointDireita;

    private float direcao = 1f;

    public Enemy(World world, int[][] nivel, float waypointA, float waypointB, float y) {
        this.nivel = nivel;
        this.waypointEsquerda = Math.min(waypointA, waypointB);
        this.waypointDireita = Math.max(waypointA, waypointB);

        this.body = criarBody(world, (waypointEsquerda + waypointDireita) / 2f, y);
        body.setLinearVelocity(direcao * VELOCIDADE, 0f);
    }

    private Body criarBody(World world, float x, float y) {

        BodyDef bodyDef = new BodyDef();
        bodyDef.type = BodyDef.BodyType.KinematicBody;
        bodyDef.position.set(x, y);
        bodyDef.allowSleep = false;
        Body corpo = world.createBody(bodyDef);

        PolygonShape shape = new PolygonShape();
        shape.setAsBox(LARGURA / 2f, ALTURA / 2f);

        FixtureDef fixtureDef = new FixtureDef();
        fixtureDef.shape = shape;
        Fixture fixture = corpo.createFixture(fixtureDef);
        fixture.setUserData(TipoColisor.INIMIGO);
        shape.dispose();

        return corpo;
    }

    public void update(float delta) {
        if (alcancouWaypoint() || vaziouOuParedeAFrente()) {
            direcao *= -1f;
        }

        body.setLinearVelocity(direcao * VELOCIDADE, 0f);
    }

    private boolean alcancouWaypoint() {
        float x = getX();
        return (direcao > 0f && x >= waypointDireita) || (direcao < 0f && x <= waypointEsquerda);
    }

    private boolean vaziouOuParedeAFrente() {
        float xFrente = getX() + direcao * DISTANCIA_DE_DETECCAO;
        int coluna = TileMapLoader.colunaDe(xFrente);

        int linhaDosPes = TileMapLoader.linhaDeBaixoDe(getY() - ALTURA / 2f - 0.1f);
        boolean semChaoNaFrente = TileMapLoader.tileEm(nivel, coluna, linhaDosPes) == TileMapLoader.VAZIO;

        int linhaDoCorpo = TileMapLoader.linhaDeBaixoDe(getY());
        boolean paredeNaFrente = TileMapLoader.tileEm(nivel, coluna, linhaDoCorpo) != TileMapLoader.VAZIO;

        return  semChaoNaFrente || paredeNaFrente;
    }

    public float getX() {
        return body.getPosition().x;
    }

    public float getY() {
        return body.getPosition().y;
    }

    public void destruir(World world) {
        world.destroyBody(body);
    }
}
