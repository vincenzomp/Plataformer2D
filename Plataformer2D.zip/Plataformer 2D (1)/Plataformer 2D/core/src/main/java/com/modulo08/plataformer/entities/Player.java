package com.modulo08.plataformer.entities;

import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.*;
import com.modulo08.plataformer.systems.TileMapLoader;
import com.modulo08.plataformer.systems.TipoColisor;

public class Player {

    public static final float LARGURA = 0.8f;
    public static final float ALTURA = 1.0f;
    private static final float DISTANCIA_DE_DETECCAO_PAREDE = LARGURA / 2f + 0.05f;
    private static final float VELOCIDADE_MAX_HORIZONTAL = 5f;
    private static final float ACELERACAO_CHAO = 30f;
    private static final float ACELERACAO_AR = 10f;
    private static final float COYOTE_TIME = 0.1f;
    private static final float JUMP_BUFFER_TIME = 0.15f;

    private final Body body;

    private float velocidadeHorizontal = 0f;
    private float velocidadeVertical = 0f;

    private final float gravidade = -20f;
    private final float velocidadePulo = 10f;
    private final float velocidadeQuique = 6f;

    private boolean isGrounded = false;
    private float coyoteTimer = 0f;
    private float jumBufferTimer = 0f;
    private boolean precisaEncaixarNoChao = false;
    private float topoDoChaoAtual = 0f;
    private final int[][] nivel;

    public Player(World world, int[][] nivel, float x, float y) {
        this.nivel = nivel;
        this.body = criarBody(world, x, y);
    }

    private Body criarBody(World world, float x, float y) {
        BodyDef bodyDef = new BodyDef();
        bodyDef.type = BodyDef.BodyType.KinematicBody;
        bodyDef.position.set(x, y);
        bodyDef.allowSleep = false;
        Body corpo = world.createBody(bodyDef);

        PolygonShape corpoShape = new PolygonShape();
        corpoShape.setAsBox(LARGURA / 2f, ALTURA / 2f);

        FixtureDef corpoFixtureDef = new FixtureDef();
        corpoFixtureDef.shape = corpoShape;
        Fixture corpoFixture = corpo.createFixture(corpoFixtureDef);
        corpoFixture.setUserData(TipoColisor.JOGADOR_CORPO);
        corpoShape.dispose();

        PolygonShape pesShape = new PolygonShape();
        pesShape.setAsBox(LARGURA / 2f * 0.8f, 0.05f, new Vector2(0, -ALTURA / 2f), 0);

        FixtureDef pesFixtureDef = new FixtureDef();
        pesFixtureDef.shape = pesShape;
        pesFixtureDef.isSensor = true;
        Fixture pesFixture = corpo.createFixture(pesFixtureDef);
        pesFixture.setUserData(TipoColisor.JOGADOR_PES);
        pesShape.dispose();

        return corpo;
    }

    public boolean pular() {
        if (isGrounded || coyoteTimer > 0f) {
            executarPulo();
            return true;
        }

        jumBufferTimer = JUMP_BUFFER_TIME;
        return false;
    }

    private void executarPulo() {
        velocidadeVertical = velocidadePulo;
        isGrounded = false;
        coyoteTimer = 0f;
        jumBufferTimer = 0f;
    }

    public void setGrounded(boolean grounded) {
        if (this.isGrounded && !grounded) {
            coyoteTimer = COYOTE_TIME;
        }
        this.isGrounded = grounded;
        if (grounded) {
            if (jumBufferTimer > 0f) {
                executarPulo();
            } else {
                velocidadeVertical = 0f;
            }
        }
    }

    public void registrarTopoDoChao(float topoDoChao) {
        this.topoDoChaoAtual = topoDoChao;
        this.precisaEncaixarNoChao = true;
    }

    public void aplicarCorrecaoDePosicao() {
        if (precisaEncaixarNoChao) {
            body.setTransform(getX(), topoDoChaoAtual + ALTURA / 2f, 0f);
            precisaEncaixarNoChao = false;
        }
    }

    public void update(float delta, float direcaoHorizontal) {
        float aceleracao = isGrounded ? ACELERACAO_CHAO : ACELERACAO_AR;
        if (direcaoHorizontal != 0f) {
            velocidadeHorizontal += direcaoHorizontal * aceleracao * delta;
            velocidadeHorizontal = MathUtils.clamp(velocidadeHorizontal, -VELOCIDADE_MAX_HORIZONTAL, VELOCIDADE_MAX_HORIZONTAL);
        } else if (velocidadeHorizontal > 0f) {
            velocidadeHorizontal = Math.max(0f, velocidadeHorizontal - aceleracao * delta);
        } else if (velocidadeHorizontal < 0f) {
            velocidadeHorizontal = Math.min(0f, velocidadeHorizontal + aceleracao * delta);
        }

        if (velocidadeHorizontal > 0f && paredeNaFrente(1f)) {
            velocidadeHorizontal = 0f;
        } else if (velocidadeHorizontal < 0f && paredeNaFrente(-1f)) {
            velocidadeHorizontal = 0f;
        }

        velocidadeVertical += gravidade * delta;

        if (isGrounded && velocidadeVertical < 0f) {
            velocidadeVertical = 0f;
        }

        body.setLinearVelocity(velocidadeHorizontal, velocidadeVertical);

        if (coyoteTimer > 0f) {
            coyoteTimer -= delta;
        }

        if (jumBufferTimer > 0f) {
            jumBufferTimer -= delta;
        }
    }

    private boolean paredeNaFrente(float direcaoMovimento) {
        float xFrente = body.getPosition().x + direcaoMovimento * DISTANCIA_DE_DETECCAO_PAREDE;
        int coluna = TileMapLoader.colunaDe(xFrente);
        float y = body.getPosition().y;

        float[] deslocamentosVerticais = { -ALTURA / 2f + 0.1f, 0f, ALTURA / 2f - 0.1f};
        for (float dy : deslocamentosVerticais) {
            int linhaDeBaixo = TileMapLoader.linhaDeBaixoDe(y + dy);
            if (TileMapLoader.tileEm(nivel, coluna, linhaDeBaixo) != TileMapLoader.VAZIO) {
                return  true;
            }
        }

        return false;
    }

    public void quicar() {
        velocidadeVertical = velocidadeQuique;
        isGrounded = false;
        coyoteTimer = 0f;
    }

    public float getX() {
        return body.getPosition().x;
    }

    public float getY() {
        return body.getPosition().y;
    }

    public boolean isGrounded() {
        return isGrounded;
    }

}
