package com.modulo08.plataformer.screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.Box2DDebugRenderer;
import com.badlogic.gdx.physics.box2d.World;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.modulo08.plataformer.Main;
import com.modulo08.plataformer.entities.Enemy;
import com.modulo08.plataformer.entities.Player;
import com.modulo08.plataformer.systems.GameCamera;
import com.modulo08.plataformer.systems.PlayerContactListener;
import com.modulo08.plataformer.systems.TileMapLoader;

public class GameScreen implements Screen {

    private static final float VIEWPORT_WIDTH = 16f;
    private static final float VIERWPORT_HEIGHT = 9f;
    private static final float POSICAO_X_JOGADOR = 2f;
    private static final float POSICAO_Y_JOGADOR = 3f;
    private static final float MARGEM_PISADA = 0.15f;

    private final Main game;

    private GameCamera camera;
    private Viewport viewport;
    private World world;
    private Box2DDebugRenderer debugRenderer;
    private PlayerContactListener contactListener;
    private Player player;
    private Enemy enemy;

    public GameScreen(Main game) {
        this.game = game;
    }

    @Override
    public void show() {
        camera = new GameCamera(VIEWPORT_WIDTH, VIERWPORT_HEIGHT);
        viewport = new FitViewport(VIEWPORT_WIDTH, VIERWPORT_HEIGHT, camera);
        debugRenderer = new Box2DDebugRenderer();

        iniciarFase();
    }

    private void iniciarFase() {

        world = new World(new Vector2(0, 0), true);
        int[][] nivel = TileMapLoader.criarNivel();
        TileMapLoader.carregarTiles(world, nivel);
        TileMapLoader.criarZonaMorte(world, nivel);

        player = new Player(world, nivel, POSICAO_X_JOGADOR, POSICAO_Y_JOGADOR);
        contactListener = new PlayerContactListener(player);
        world.setContactListener(contactListener);

        enemy = new Enemy(world, nivel, 1.5f, 9.7f, 1.3f);

        camera.position.set(POSICAO_X_JOGADOR, POSICAO_Y_JOGADOR, 0);
        camera.update();
    }

    private void reiniciarFase() {
        world.dispose();
        iniciarFase();
    }

    @Override
    public void render(float delta) {
        float direcaoHorizontal = 0f;
        if (Gdx.input.isKeyPressed(Input.Keys.A) || Gdx.input.isKeyPressed(Input.Keys.LEFT)) {
            direcaoHorizontal -= 1f;
        }

        if (Gdx.input.isKeyPressed(Input.Keys.D) || Gdx.input.isKeyPressed(Input.Keys.RIGHT)) {
            direcaoHorizontal += 1f;
        }
        if (Gdx.input.isKeyJustPressed(Input.Keys.SPACE)) {
            player.pular();
        }

        player.update(delta, direcaoHorizontal);
        if (enemy != null) {
            enemy.update(delta);
        }

        world.step(1 / 60f, 6, 2);
        player.aplicarCorrecaoDePosicao();

        boolean jogadorMorreu = contactListener.jogadorCaiu();
        if (!jogadorMorreu && enemy != null && colidiuComInimigo()) {
            if (piscandoNoInimigo()) {
                enemy.destruir(world);
                enemy = null;
                player.quicar();
            } else {
                jogadorMorreu = true;
            }
        }

        if (jogadorMorreu) {
            reiniciarFase();
        } else {
            Vector2 posicaoJogador = new Vector2(player.getX(), player.getY());
            camera.followTarget(posicaoJogador, delta);
            camera.update();
        }

        ScreenUtils.clear(Color.BLACK);
        debugRenderer.render(world, camera.combined);
    }

    private boolean colidiuComInimigo() {
        float dx = Math.abs(player.getX() - enemy.getX());
        float dy = Math.abs(player.getY() - enemy.getY());
        return dx < (Player.LARGURA + Enemy.LARGURA) / 2f && dy < (Player.ALTURA + Enemy.ALTURA) / 2f;
    }

    private boolean piscandoNoInimigo() {
        float baseJogador = player.getY() - Player.ALTURA / 2f;
        float topoInimigo = enemy.getY() - Enemy.ALTURA / 2f;
        return baseJogador >= topoInimigo - MARGEM_PISADA;
    }

    @Override
    public void resize(int width, int height) {
        viewport.update(width, height, true);
    }

    @Override public void pause() {}
    @Override public void resume() {}
    @Override public void hide() {}
    @Override public void dispose() {
        world.dispose();
        debugRenderer.dispose();
    }
}
