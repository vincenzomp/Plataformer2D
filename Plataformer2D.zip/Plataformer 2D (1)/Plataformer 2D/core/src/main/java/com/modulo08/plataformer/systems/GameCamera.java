package com.modulo08.plataformer.systems;

import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.math.Vector2;

public class GameCamera extends OrthographicCamera {

    private static final float LERP_ALPHA = 3f;

    public GameCamera(float viewportWidth, float viewportHeight) {
        super(viewportWidth, viewportHeight);
    }

    public void followTarget(Vector2 target, float delta) {
        Vector2 posicaoAtual = new Vector2(position.x, position.y);
        posicaoAtual.lerp(target, LERP_ALPHA * delta);
        position.set(posicaoAtual, 0);
    }
}
