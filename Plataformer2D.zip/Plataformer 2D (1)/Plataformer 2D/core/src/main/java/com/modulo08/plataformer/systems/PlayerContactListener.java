package com.modulo08.plataformer.systems;

import com.badlogic.gdx.physics.box2d.*;
import com.modulo08.plataformer.entities.Player;

public class PlayerContactListener implements ContactListener {

    private final Player player;
    private boolean jogadorCaiu = false;
    private int contatosComChao = 0;

    public PlayerContactListener(Player player) {
        this.player = player;
    }

    @Override
    public void beginContact(Contact contact) {
        Fixture fixturePes = obterFixturePes(contact);
        Fixture fixtureChao = obterFixtureChao(contact);
        if (fixturePes != null && fixtureChao != null) {
            contatosComChao++;
            if (contatosComChao == 1) {
                player.setGrounded(true);
            }

            float topoDoTile = fixtureChao.getBody().getPosition().y + TileMapLoader.TILE_SIZE / 2f;
            player.registrarTopoDoChao(topoDoTile);
        }

        if (envolveJogador(contact, TipoColisor.ZONA_MORTE)) {
            jogadorCaiu = true;
        }
    }

    @Override
    public void endContact(Contact contact) {
        Fixture fixturePes = obterFixturePes(contact);
        Fixture fixtureChao = obterFixtureChao(contact);

        if (fixturePes != null && fixtureChao != null) {
            contatosComChao = Math.max(0, contatosComChao - 1);
            if (contatosComChao == 0) {
                player.setGrounded(false);
            }
        }
    }

    @Override public void preSolve(Contact contact, Manifold manifold) {}
    @Override public void postSolve(Contact contact, ContactImpulse impulse) {}

    private Fixture obterFixturePes(Contact contact) {
        if (contact.getFixtureA().getUserData() == TipoColisor.JOGADOR_PES) {
            return contact.getFixtureA();
        }
        if (contact.getFixtureB().getUserData() == TipoColisor.JOGADOR_PES) {
            return contact.getFixtureB();
        }

        return null;
    }

    private Fixture obterFixtureChao(Contact contact) {
        if (contact.getFixtureA().getUserData() == TipoColisor.CHAO) {
            return contact.getFixtureA();
        }
        if (contact.getFixtureB().getUserData() == TipoColisor.CHAO) {
            return contact.getFixtureB();
        }

        return null;
    }

    private boolean envolveJogador(Contact contact, TipoColisor outroTipo) {
        Object dadoA = contact.getFixtureA().getUserData();
        Object dadoB = contact.getFixtureB().getUserData();
        boolean aEhJogador = dadoA == TipoColisor.JOGADOR_CORPO || dadoA == TipoColisor.JOGADOR_PES;
        boolean bEhJogador = dadoB == TipoColisor.JOGADOR_CORPO || dadoB == TipoColisor.JOGADOR_PES;
        return (aEhJogador && dadoB == outroTipo) || (bEhJogador && dadoA == outroTipo);
    }

    public boolean jogadorCaiu() {
        return jogadorCaiu;
    }
}
