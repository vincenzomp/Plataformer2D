package com.modulo08.plataformer.systems;

import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.physics.box2d.*;

public class TileMapLoader {

    public static final int VAZIO = 0;
    public static final int CHAO = 1;
    public static final int PAREDE = 2;
    public static final float TILE_SIZE = 1f;

    private TileMapLoader() {
    }

    public static int[][] criarNivel() {
        int largura = 28;
        int altura = 12;
        int[][] nivel = new int[altura][largura];

        preencherFaixaHorizontal(nivel, 0, 8, 0, CHAO);
        preencherFaixaHorizontal(nivel, 11, 20, 0, CHAO);
        preencherFaixaHorizontal(nivel, 23, largura - 1, 0, CHAO);
        preencherFaixaVertical(nivel, 0, 0, 5, PAREDE);
        preencherFaixaVertical(nivel, largura - 1, 0, 5, PAREDE);

        return nivel;
    }

    private static void preencherFaixaHorizontal(int[][] nivel, int colInicio, int colFim, int linhaDeBaixo, int tipo) {
        int linha = nivel.length - 1 - linhaDeBaixo;
        for (int col = colInicio; col <= colFim; col++) {
            nivel[linha][col] = tipo;
        }
    }

    private static void preencherFaixaVertical(int[][] nivel, int col, int linhaDeBaixoInicio, int linhaDeBaixoFim, int tipo) {
        for (int linhaDeBaixo = linhaDeBaixoInicio; linhaDeBaixo <= linhaDeBaixoFim; linhaDeBaixo++) {
            int linha = nivel.length - 1 - linhaDeBaixo;
            nivel[linha][col] = tipo;
        }
    }

    private static final float MARGEM_QUEDA = 2f;
    private static final float ALTURA_ZONA_MORTE = 5f;

    public static void carregarTiles(World world, int[][] nivel) {
        for (int y = 0; y < nivel.length; y++) {
            for (int x = 0; x < nivel[y].length; x++) {
                if (nivel[y][x] != VAZIO) {
                    criarTileFisico(world, x, nivel.length - 1 - y, nivel[y][x]);
                }
            }
        }
    }

    public static void criarZonaMorte(World world, int[][] nivel) {
        int larguraMundo = nivel[0].length;

        BodyDef bodyDef = new BodyDef();
        bodyDef.type = BodyDef.BodyType.DynamicBody;
        bodyDef.position.set(larguraMundo * TILE_SIZE / 2f, -MARGEM_QUEDA - ALTURA_ZONA_MORTE / 2f);
        bodyDef.allowSleep = false;

        Body body = world.createBody(bodyDef);

        PolygonShape shape = new PolygonShape();
        shape.setAsBox(larguraMundo * TILE_SIZE / 2f, ALTURA_ZONA_MORTE / 2f);

        FixtureDef fixtureDef = new FixtureDef();
        fixtureDef.shape = shape;
        fixtureDef.isSensor = true;
        Fixture fixture = body.createFixture(fixtureDef);
        fixture.setUserData(TipoColisor.ZONA_MORTE);

        shape.dispose();
    }

    private static void criarTileFisico(World world, int col, int linhaInverida, int tipoTile) {
        BodyDef bodyDef = new BodyDef();
        bodyDef.type = BodyDef.BodyType.DynamicBody;
        bodyDef.position.set(col * TILE_SIZE + TILE_SIZE / 2f, linhaInverida * TILE_SIZE + TILE_SIZE / 2f);
        bodyDef.allowSleep = false;

        Body body = world.createBody(bodyDef);

        PolygonShape shape = new PolygonShape();
        shape.setAsBox(TILE_SIZE / 2f, TILE_SIZE / 2f);

        FixtureDef fixtureDef = new FixtureDef();
        fixtureDef.shape = shape;
        fixtureDef.isSensor = true;
        Fixture fixture = body.createFixture(fixtureDef);
        fixture.setUserData(tipoTile == PAREDE ? TipoColisor.PAREDE : TipoColisor.CHAO);

        shape.dispose();
    }

    public static int colunaDe(float worldX) {
        return MathUtils.floor(worldX / TILE_SIZE);
    }

    public static int linhaDeBaixoDe(float worldY) {
        return MathUtils.floor(worldY / TILE_SIZE);
    }

    public static int tileEm(int[][] nivel, int col, int linhaDeBaixo) {
        int linha = nivel.length - 1 - linhaDeBaixo;
        if (linha < 0 || linha >= nivel.length || col < 0 || col >= nivel[linha].length) {
            return VAZIO;
        }

        return nivel[linha][col];
    }
}

