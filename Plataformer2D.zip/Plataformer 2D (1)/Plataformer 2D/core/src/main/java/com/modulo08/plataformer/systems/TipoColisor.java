package com.modulo08.plataformer.systems;

public enum TipoColisor {
    JOGADOR_CORPO,
    JOGADOR_PES,
    CHAO,
    PAREDE,
    INIMIGO,
    ZONA_MORTE
}
